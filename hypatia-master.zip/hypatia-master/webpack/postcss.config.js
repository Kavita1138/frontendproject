const autoPrefixer = require('autoprefixer');

module.exports = {
	plugins: [
		autoPrefixer({ /* ...options */ })
	]
};
